﻿using System.Windows.Forms;
using System;
using System.IO;
using iText.Forms;
using iText.Forms.Fields;
using iText.IO.Font.Constants;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Action;
using iText.Kernel.Pdf.Annot;
using iText.Kernel.Pdf.Canvas;

namespace PDF_Text_Stamper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        public virtual void ManipulatePdf(String src, String dest)
        {
            //Initialize PDF document
            PdfDocument pdfDoc = new PdfDocument(new PdfReader(src), new PdfWriter(dest));
            //Add text
            PdfCanvas canvas = new PdfCanvas(pdfDoc.GetFirstPage());
            canvas.BeginText().SetFontAndSize(PdfFontFactory.CreateFont(StandardFonts.HELVETICA), 12).MoveText(265, 597).ShowText(textBox1.Text).EndText();
            PdfCanvas canvas2 = new PdfCanvas(pdfDoc.GetFirstPage());
            canvas2.BeginText().SetFontAndSize(PdfFontFactory.CreateFont(StandardFonts.HELVETICA), 12).MoveText(200, 597).ShowText(textBox2.Text).EndText();
            pdfDoc.Close();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            String SRC = "C:/Users/Julien/Documents/Test PDF Writing/PDF Text Stamper/test/exemple.pdf";
            String DEST = "C:/Users/Julien/Documents/Test PDF Writing/PDF Text Stamper/test/exemple_m.pdf";
            ManipulatePdf(SRC, DEST);
        }
    }
}
/*------------------------------------------------------
        using System;
        using System.IO;
        using iText.Forms;
        using iText.Forms.Fields;
        using iText.IO.Font.Constants;
        using iText.Kernel.Font;
        using iText.Kernel.Geom;
        using iText.Kernel.Pdf;
        using iText.Kernel.Pdf.Action;
        using iText.Kernel.Pdf.Annot;
        using iText.Kernel.Pdf.Canvas;

        namespace Tutorial.Chapter05
            {
                /// <summary>Simple adding annotations example.</summary>
                public class C05E01_AddAnnotationsAndContent
                {
                    public const String SRC = "C:/Users/Julien/Documents/Test PDF Writing/PDF Text Stamper/test/exemple.pdf";
                    public const String DEST = "C:/Users/Julien/Documents/Test PDF Writing/PDF Text Stamper/test/exemple_m.pdf";

                    public static void Main(String[] args)
                    {
                        FileInfo file = new FileInfo(DEST);
                        file.Directory.Create();
                        new C05E01_AddAnnotationsAndContent().ManipulatePdf(SRC, DEST);
                    }

                    public virtual void ManipulatePdf(String src, String dest)
                    {
                        //Initialize PDF document
                        PdfDocument pdfDoc = new PdfDocument(new PdfReader(src), new PdfWriter(dest));
                        //Add text annotation
                        PdfAnnotation ann = new PdfTextAnnotation(new Rectangle(400, 795, 0, 0))
                            .SetOpen(true)
                            .SetTitle(new PdfString("iText"))
                            .SetContents("Please, fill out the form.");
                        pdfDoc.GetFirstPage().AddAnnotation(ann);
                        PdfCanvas canvas = new PdfCanvas(pdfDoc.GetFirstPage());
                        canvas.BeginText().SetFontAndSize(PdfFontFactory.CreateFont(StandardFonts.HELVETICA), 12).MoveText(265, 597
                            ).ShowText("I agree to the terms and conditions.").EndText();
                        //Add form field
                        PdfAcroForm form = PdfAcroForm.GetAcroForm(pdfDoc, true);
                        PdfButtonFormField checkField = PdfFormField.CreateCheckBox(pdfDoc, new Rectangle(245, 594, 15, 15), "agreement"
                            , "Off", PdfFormField.TYPE_CHECK);
                        checkField.SetRequired(true);
                        form.AddField(checkField);
                        //Update reset button
                        form.GetField("reset").SetAction(PdfAction.CreateResetForm(new String[] { "name", "language", "experience1"
                        , "experience2", "experience3", "shift", "info", "agreement" }, 0));
                        pdfDoc.Close();
                    }
                }
            }
            ------------------------------------------------------*/